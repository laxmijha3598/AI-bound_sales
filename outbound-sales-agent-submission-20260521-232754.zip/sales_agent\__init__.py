"""Outbound sales agent package."""

